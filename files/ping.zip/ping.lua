-------------------------
local mode=0 -- 1 - с отображением рамки, 0 - только звук, 2 - сообщение не исчезнет, пока вы не отправите что-нибудь в чат
-------------------------
script_name("Ping!")
script_version("1.0")
script_author("BezlikiY")

local font = renderCreateFont('Arial', 10, 13)
local sampev = require('lib.samp.events')
local x, y = getScreenResolution()
local texstring=""
local sendstring="                      "

function main()
  if not isSampfuncsLoaded() then print("SAMPFUNCS не был загружен.") return end
  if not isSampLoaded() then print("SA:MP не был загружен.") return end
  while true do
  if draw then for i=1,50,1 do
			renderDrawLine(0+10, 0, x+10, 0, 10, 0xFFFF0000)
			renderDrawLine(0+10, y, x+10, y, 10, 0xFFFF0000)
			renderDrawLine(0+10, 0, 0+10, y, 10, 0xFFFF0000)
			renderDrawLine(x+10, 0, x+10, y, 10, 0xFFFF0000)
			renderFontDrawText(font, texstring, 40, y-40, 0xFFFFFFFF)
			wait(0)
		end
		if mode==1 then draw = false end
		
	end
  wait(0)
  end
end

function sampev.onServerMessage(color, text)
	if string.find(text, getMyName()) and not string.find(text, sendstring) then 
		texstring = text
		addOneOffSound(0.0, 0.0, 0.0, 1054) 
		if mode>0 then draw = true end
	end
	sendstring="               "
--	return true
end

function getMyName()
	local ok, id = sampGetPlayerIdByCharHandle(PLAYER_PED)
	if ok then
		return sampGetPlayerNickname(id)
	else
		return 'Unknown'
	end
end

function sampev.onSendChat(send)
	sendstring = send
	draw = false
end